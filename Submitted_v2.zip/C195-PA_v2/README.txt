Title: C195 Software 2
Purpose of Application: Allow users to create customer records and appointments for customer records; and all data is uploaded to a database.


Author: Muhammad Chambers
Contact Information: mcha581@wgu.wdu
Student Application Version: 2.0
Date: 28 September 2023

IDE & Version Number: IntelliJ IDEA v2022.2
JDK: 17.0.8
JavaFX: 19


Directions of how to run the program:
- You'll need to add the MySQL connector in the project settings as a java library 
- You may need to edit the configurations in IntelliJ to run the program. An easy way that I found was clicking the first
green run arrow on the left hand side inside of the Login class with the main method.
- The password for the login screen is test, and the username is test


Description of the additional report of your choice you ran in part A3f:
For the 3rd additional report I decided to pull data on the number of appointments each customer id has for each month.


MySQL Connector Driver Version Number: 8.1.0